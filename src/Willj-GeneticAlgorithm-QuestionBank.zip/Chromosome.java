
public class Chromosome implements Comparable<Chromosome> {
  
  public int[] genes;
  int fitnessScore;
  
  public Chromosome(int numberOfGenes) {
    genes = new int[numberOfGenes];
    fitnessScore = 0;
  }
  
  public Chromosome(int numberOfGenes, int[] values) {
    genes = new int[numberOfGenes];
    fitnessScore = 0;
    for (int i=0; i<values.length; i++)
      genes[i] = values[i];
  }
  
  
  public void singlePointCrossover(Chromosome parent1, Chromosome parent2) {
    
    int chromosomeSize = parent1.genes.length;
    int mid = chromosomeSize / 2;
    
    for (int i = 0; i<mid; i++)
      setGene(i,parent1.getGene(i));
    
    for (int i = mid; i<chromosomeSize; i++)
      setGene(i,parent2.getGene(i));
  }
  
  
  public void threePointCrossover(Chromosome parent1, Chromosome parent2) {
    
    int chromosomeSize = parent1.genes.length;
    int firstThirdEnd = chromosomeSize / 3;
    int secondThirdEnd = (firstThirdEnd + chromosomeSize)/2;
    
    for (int i = 0; i<firstThirdEnd; i++)
      setGene(i,parent1.getGene(i));
    
    for (int i = firstThirdEnd; i<secondThirdEnd; i++)
      setGene(i,parent2.getGene(i));
    
    for (int i = secondThirdEnd; i<chromosomeSize; i++)
      setGene(i,parent1.getGene(i));
  }
  
  public void randomCrossover(Chromosome parent1, Chromosome parent2) {
    for (int i = 0; i<parent1.genes.length; i++) {
      if (Math.random() < 0.5)
        setGene(i,parent1.getGene(i));
      else
        setGene(i,parent2.getGene(i));
    }
  }
  
  // Bit flip mutation
  public void mutate(double mutationRate) {
    for (int i=0; i<genes.length; i++) {
      if (Math.random() <= mutationRate) {
        if (genes[i] == 0)
          genes[i] = 1;
        else
          genes[i] = 0;
      }
    }
  }
  
  public void setRandomGenes() {
    
    for (int i=0; i<genes.length; i++) {
      genes[i] = (Math.random() < 0.5 ? 1 : 0);
    }
  }
  
  public int getGene(int index) {
    return genes[index];
  }
  
  public void setGene(int index, int value) {
    genes[index] = value;
  }
  
  public int getFitnessScore() {
    return fitnessScore;
  }
  
  public void setFitnessScore(int score) {
    fitnessScore = score;
  }
  
  public int geneCount() {
    return genes.length;
  }
  
  @Override
  public int compareTo(Chromosome other) {
    return Integer.compare(this.fitnessScore, other.fitnessScore);
  }
  
  public void print() {
    System.out.print("Fitness score: " + fitnessScore + " Genes: ");
    for (int i=0; i<genes.length; i++) {
      System.out.print(genes[i] + " ");
    }
    System.out.println();
  }
}
