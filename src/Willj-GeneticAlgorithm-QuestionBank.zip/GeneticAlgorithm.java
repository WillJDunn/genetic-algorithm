
// O(g(nm + nm + n)) with g the number of generations, n the population size and m the size of the individuals
public class GeneticAlgorithm {
  
  public GeneticAlgorithm() {
    // Initialize
  }
  
  public void algorithm1(Genotype genotype, int populationSize, int numberOfChildren, int selectBest, int bestScoreTarget) {
    
    System.out.println("Source population:");
    Population population = new Population(genotype);
    population.generateRandom(populationSize);
    System.out.println("Average score:" + population.getAverageScore()
                     + " Best score: " + population.getBestScore());
    System.out.println("Size: " + population.size());
    
    Selector selector = new Selector();
    
    int generation = 1;
    
    while (population.getBestScore()<bestScoreTarget) {
      System.out.println("GENERATION " + generation);
      System.out.println("  Parents1 (roulette):");
      Population parents1 = new Population(genotype);
      parents1 = selector.rolluletteWheelSelection(population, numberOfChildren/2);
      System.out.println("    Average score:" + parents1.getAverageScore()
                      + " Best score: " + parents1.getBestScore()
                      + " Size: " + parents1.size());
      
      System.out.println("  Parents2 (roulette):");
      Population parents2 = new Population(genotype);
      parents2 = selector.rolluletteWheelSelection(population, numberOfChildren/2);
      System.out.println("    Average score:" + parents2.getAverageScore()
                      + " Best score: " + parents2.getBestScore()
                      + " Size: " + parents2.size());
      
      
      System.out.println("  Child population1 (single point crossover):");
      Population children1 = new Population(genotype);
      children1 = parents1.generateChildren("singlePointCrossover");
      System.out.println("    Average score:" + children1.getAverageScore()
                       + " Best score: " + children1.getBestScore()
                       + " Size: " + children1.size());
      
      System.out.println("  Child population2 (random crossover):");
      Population children2 = new Population(genotype);
      children2 = parents2.generateChildren("randomCrossover");
      System.out.println("    Average score:" + children2.getAverageScore()
                       + " Best score: " + children2.getBestScore()
                       + " Size: " + children2.size());
      
      System.out.println("  Survivors " + selectBest + " best (ranked):");
      Population best = new Population(genotype);
      best = selector.rankSelection(population, selectBest);
      System.out.println("    Average score:" + best.getAverageScore()
                       + " Best score: " + best.getBestScore()
                       + " Size: " + best.size());
      
      System.out.println("  Survivors (rouletteWheel):");
      Population survivors1 = new Population(genotype);
      survivors1 = selector.tournamentSelection(population, (populationSize - numberOfChildren - selectBest)/2);
      System.out.println("    Average score:" + survivors1.getAverageScore()
                       + " Best score: " + survivors1.getBestScore()
                       + " Size: " + survivors1.size());
      
      System.out.println("  Survivors (tournament):");
      Population survivors2 = new Population(genotype);
      survivors2 = selector.tournamentSelection(population, (populationSize - numberOfChildren - selectBest)/2);
      System.out.println("    Average score:" + survivors2.getAverageScore()
                       + " Best score: " + survivors2.getBestScore()
                       + " Size: " + survivors2.size());
      
      System.out.println("  New generation:");
      Population newGeneration = new Population(genotype);
      newGeneration.add(survivors1);
      newGeneration.add(survivors2);
      newGeneration.add(best);
      newGeneration.add(children1);
      newGeneration.add(children2);
      newGeneration.mutate(0.005);
      System.out.println("    Average score:" + newGeneration.getAverageScore()
                       + " Best score: " + newGeneration.getBestScore()
                       + " New generation size: " + newGeneration.size()); 
      
      population = newGeneration;
      
      generation++;
    }
    System.out.println("Best solution:");
    genotype.printChromosome(population.getBest());
  }
}
